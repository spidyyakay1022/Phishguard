# PhishGuard AI - Frontend

React + Vite + Tailwind. Pages: Landing (/), Analyze (/analyze), Results (/results).

## Run it
1. Install Node.js LTS from https://nodejs.org
2. In this folder, run: `npm install` then `npm run dev`
3. Open the link it prints (http://localhost:5173)

## Mock mode vs real backend
`.env` has `VITE_USE_MOCK=true`, so the app works with a fake analyzer.
When the backend is ready, set it to `false` and restart `npm run dev`.
The backend must follow the contract written at the top of `src/lib/api.js`.

## Where things live
- `src/pages/` - one file per screen
- `src/components/` - reusable pieces (score gauge, threat card, navbar)
- `src/lib/api.js` - the only file that talks to the backend
- `src/index.css` - colors and fonts
